#define SCALE 31

int compareEqual(number a, number b);
void decimalEqual(number *a, number *b);
number *add(number *a, number *b);
number *sub(number *a, number *b);
number *mult(number *a, number *b);
number *division(number *a, number *b);
